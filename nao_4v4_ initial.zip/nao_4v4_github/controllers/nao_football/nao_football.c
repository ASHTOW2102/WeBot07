#include <stdio.h>
#include <webots/camera.h>
#include <webots/robot.h>

// Shared controller for the eight NAO V5 players.
// It initializes the cameras and waits for future football behavior code.
// No timeline, motion playback, walking, turning, or kicking is configured.
int main(void) {
  wb_robot_init();
  const int time_step = (int)wb_robot_get_basic_time_step();
  const WbDeviceTag top_camera = wb_robot_get_device("CameraTop");
  const WbDeviceTag bottom_camera = wb_robot_get_device("CameraBottom");
  wb_camera_enable(top_camera, time_step);
  wb_camera_enable(bottom_camera, time_step);

  printf("[%s] nao_football ready: no scheduled actions.\n", wb_robot_get_name());
  fflush(stdout);

  while (wb_robot_step(time_step) != -1) {
    // Future code: read sensors, choose football behavior, command actuators.
  }

  wb_robot_cleanup();
  return 0;
}
