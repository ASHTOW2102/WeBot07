# 上游资源来源

本项目引用 Cyberbotics Webots R2025a 的模型，并包含该版本的 NAO 动作文件。

- NAO 模型：https://github.com/cyberbotics/webots/tree/R2025a/projects/robots/softbank/nao/protos
- NAO 动作：https://github.com/cyberbotics/webots/tree/R2025a/projects/robots/softbank/nao/motions
- 球场和球门：https://github.com/cyberbotics/webots/tree/R2025a/projects/objects/robotstadium/protos
- 足球：https://github.com/cyberbotics/webots/tree/R2025a/projects/objects/balls/protos

上游资源保留各自的许可和归属；本说明不改变上游资源的许可。