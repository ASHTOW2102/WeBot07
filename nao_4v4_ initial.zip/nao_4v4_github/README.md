# Webots NAO V5 足球 4v4

这是 Webots R2025a 的 NAO V5 足球仿真学习项目，包含 8 个机器人、足球、球场和球门。
当前版本完成场景布置；所有机器人使用 `nao_football` 待命控制器，初始化摄像头后持续推进仿真，没有预设走路或踢球行为。

## 文件结构

```text
controllers/
  nao_football/
    nao_football.c     # 当前 C 控制器源码
    Makefile           # Webots 编译配置
worlds/
  nao_4v4.wbt          # 4v4 世界文件
motions/
  *.motion            # 后续动作控制可复用的动作文件
```

## 打开与运行

1. 安装 Webots R2025a。
2. 将完整项目下载或解压到一个目录，保留上述目录结构。
3. 在 Webots 中使用 File > Open World 打开 `worlds/nao_4v4.wbt`。
4. 使用 File > Open Text File 打开 `controllers/nao_football/nao_football.c`。
5. 在代码编辑器中使用 Build > Build（F7）编译控制器。本仓库只提供源码，首次运行前需要编译生成本机可执行文件。
6. Reload World（Ctrl+Shift+R），然后播放仿真。当前机器人保持待命，这是本版本预期行为。

模型通过世界文件中的 EXTERNPROTO 引用 Webots R2025a 官方资源。首次加载未缓存的模型时需要联网。

## 红队站位

红队在负 Y 半场，朝 +Y 方向进攻。单位为米。

| 机器人 | 位置 | X | Y | Z |
| --- | --- | ---: | ---: | ---: |
| NAO RED 1 | 前排左侧 | -1.2 | -1 | 0.334 |
| NAO RED 2 | 前排右侧 | 1.2 | -1 | 0.334 |
| NAO RED 3 | 第二排中央 | 0 | -2.3 | 0.334 |
| NAO RED 0 | 第三排守门员 | 0 | -3.8 | 0.334 |

蓝队保持原来的站位，足球位于球场中心。

## 上传 GitHub

将本目录内的 `README.md`、`.gitignore`、`THIRD_PARTY.md`、`worlds`、`controllers` 和 `motions` 上传到仓库，并保持目录结构。
ZIP 用于传输和备份；如需在 GitHub 上直接查看代码，请解压后上传里面的文件。
编译生成的 exe、对象文件以及本机缓存不需要加入仓库。

## 后续开发

射门算法的 Python 示例此前仅在聊天中提供，没有写入这个项目，本导出包不包含该示例。
可在当前控制器基础上继续开发感知、行走、射门和比赛规则。